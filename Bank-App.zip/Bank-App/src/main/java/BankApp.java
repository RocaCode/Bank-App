/*
 * BankApp.java
 */
public class BankApp {
    private Bank bank;
    public BankApp() {
        this.bank = new Bank();
        System.out.println("BankApp initialized with a new bank.");
    }
    public Bank getBank() {
        return this.bank;
    }
    public static void main(String[] args) {
        BankApp app = new BankApp();
        // Add more initialization code here if needed
    }
}