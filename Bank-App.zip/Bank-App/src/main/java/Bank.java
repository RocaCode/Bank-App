import java.util.ArrayList;

public class Bank {
    private ArrayList<Customer> customers;
    private ArrayList<Account> accounts;
    public Bank() {
        this.customers = new ArrayList<>();
        this.accounts = new ArrayList<>();
        System.out.println("Bank initialized");
    }
    public String addAccount(String customerName, String customerAddress, int customerAge, String customerPhoneNumber, int customerType, int accountType) {
        Customer customer;
        String customerNumber = String.valueOf(customers.size() + 1);
        switch (customerType) {
            case 2:
                customer = new Senior(customerName, customerAddress, customerAge, customerPhoneNumber, customerNumber);
                break;
            case 1:
                customer = new Adult(customerName, customerAddress, customerAge, customerPhoneNumber, customerNumber);
                break;
            case 3:
                customer = new Student(customerName, customerAddress, customerAge, customerPhoneNumber, customerNumber);
                break;
            default:
                throw new IllegalArgumentException("Invalid customer type");
        }
        customers.add(customer);
        Account account;
        switch (accountType) {
            case 0:
                account = new CheckingAccount(customer);
                break;
            case 1:
                account = new SavingsAccount(customer);
                break;
            default:
                throw new IllegalArgumentException("Invalid account type");
        }
        accounts.add(account);

        return account.getAccNumber();
    }

    public String makeDeposit(String accountNumber, double amount) {
        for (Account account : accounts) {
            if (account.getAccNumber().equals(accountNumber)) {
                account.deposit(amount);
                return String.format("%.2f", account.getBalance());
            }
        }
        return null;
    }

    public String makeWithdrawal(String accountNumber, double amount) {
        for (Account account : accounts) {
            if (account.getAccNumber().equals(accountNumber)) {
                account.withdrawal(amount);
                return String.format("%.2f", account.getBalance());
            }
        }
        return null;
    }

    public String getAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccNumber().equals(accountNumber)) {
                return account.toString();
            }
        }
        return null;
    }
}