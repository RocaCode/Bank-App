/*
 * CheckingAccount.java
 */
public class CheckingAccount extends Account {
    public CheckingAccount(Customer customer) {
        super(customer);
    }
    @Override
    public double deposit(double amount) {
        if (amount > 0) {
            transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 0, amount, "DEP");
            balance += amount;
            addInterest();
            tranIndex++;
        }
        return balance;
    }
    @Override
    public double withdrawal(double amount) {
        if (amount > 0) {
            double totalAmount = amount + owner.getCheckCharge();
            if (totalAmount > balance) {
                totalAmount += owner.getOverdraftPenalty();
            }
            transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 1, totalAmount, "WDR");
            balance -= totalAmount;
            tranIndex++;
        }
        return balance;
    }
    public double addInterest() {
        double interestAmount = balance * owner.getCheckInterest();
        transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 0, interestAmount, "INT");
        balance += interestAmount;
        tranIndex++;
        return balance;
    }
}
