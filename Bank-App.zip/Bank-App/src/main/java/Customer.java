/*
 * Customer.java
 */
abstract class Customer {
    private String name;
    private String address;
    private int age;
    private String phoneNumber;
    private String customerNumber;
    private int customerType;
    public Customer(String name, String address, int age, String phoneNumber, String customerNumber, int customerType) {
        this.name = name;
        this.address = address;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.customerNumber = customerNumber;
        this.customerType = customerType;
    }
    public int getCustomerType() {
        return this.customerType;
    }
    public String getName() {
        return this.name;
    }
    public String getAddress() {
        return this.address;
    }
    public int getAge() {
        return this.age;
    }
    public String getPhoneNumber() {
        return this.phoneNumber;
    }
    public String getCustomerNumber() {
        return this.customerNumber;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }
    public abstract String getType();
    public abstract double getSavingsInterest();
    public abstract double getCheckInterest();
    public abstract double getCheckCharge();
    public abstract double getOverdraftPenalty();
}