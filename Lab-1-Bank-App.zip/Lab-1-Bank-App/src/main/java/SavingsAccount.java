/*
 * SavingsAccount.java
 */
public class SavingsAccount extends Account {
    public SavingsAccount(Customer customer) {
        super(customer);
    }
    @Override
    public double deposit(double amount) {
        if (amount > 0) {
            transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 0, amount, "DEP");
            balance += amount;
            addInterest();
            tranIndex++;
        }
        return balance;
    }
    @Override
    public double withdrawal(double amount) {
        if (amount > 0) {
            transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 1, amount, "WDR");
            balance -= amount;
            tranIndex++;
        }
        return balance;
    }
    public double addInterest() {
        double interestAmount = balance * owner.getSavingsInterest();
        transactions[tranIndex] = new Transaction(owner.getCustomerNumber(), 0, interestAmount, "INT");
        balance += interestAmount;
        tranIndex++;
        return balance;
    }
}