/*
 * Transaction.java
 */
public class Transaction {
    private String customerNumber;
    private int tranType;
    private double amount;
    private String fees;
    public Transaction(String customerNumber, int tranType, double amount, String fees) {
        this.customerNumber = customerNumber;
        this.tranType = tranType;
        this.amount = amount;
        this.fees = fees;
    }
    public String getCustomerNumber() {
        return customerNumber;
    }
    public int getTranType() {
        return tranType;
    }
    public double getAmount() {
        return amount;
    }
    public String getFees() {
        return fees;
    }
    @Override
    public String toString() {
        return "Transaction [customerNumber=" + customerNumber + ", tranType=" + tranType + ", amount=" + amount + ", fees=" + fees + "]";
    }
}