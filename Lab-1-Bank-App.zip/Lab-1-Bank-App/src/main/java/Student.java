/*
 * Student.java
 */
public class Student extends Customer {
    private final double savingsInterest = 0.02; 
    private final double checkInterest = 0.005;  
    private final double checkCharge = 0.75;     
    private final double overdraftPenalty = 20.0;
    public Student(String name, String address, int age, String phoneNumber, String customerNumber) {
        super(name, address, age, phoneNumber, customerNumber, 3);
    }
    public String getType() {
        return "Student";
    }
    public double getSavingsInterest() {
        return savingsInterest;
    }
    public double getCheckInterest() {
        return checkInterest;
    }
    public double getCheckCharge() {
        return checkCharge;
    }
    public double getOverdraftPenalty() {
        return overdraftPenalty;
    }
}