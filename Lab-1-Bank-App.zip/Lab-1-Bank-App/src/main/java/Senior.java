/*
 * Senior.java
 */
public class Senior extends Customer {
    private final double savingsInterest = 0.04;
    private final double checkInterest = 0.02;
    private final double checkCharge = 0.5;
    private final double overdraftPenalty = 25.0;
    public Senior(String name, String address, int age, String phoneNumber, String customerNumber) {
        super(name, address, age, phoneNumber, customerNumber, 2);
    }
    public String getType() {
        return "Senior";
    }
    public double getSavingsInterest() {
        return savingsInterest;
    }
    public double getCheckInterest() {
        return checkInterest;
    }
    public double getCheckCharge() {
        return checkCharge;
    }
    public double getOverdraftPenalty() {
        return overdraftPenalty;
    }
}