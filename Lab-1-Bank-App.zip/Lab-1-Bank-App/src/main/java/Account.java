/*
 * Account.java
 */
public abstract class Account {
    protected int accNumber;
    protected double balance;
    protected Transaction[] transactions;
    protected int tranIndex;
    protected Customer owner;
    
    public Account(Customer owner) {
        this.owner = owner;
        this.accNumber++;
        this.balance = 0;
        this.transactions = new Transaction[20];
        this.tranIndex = 0;
    }
    
    public String getAccNumber() {
        return String.valueOf(this.accNumber);
    }
    
    public double getBalance() {
        return this.balance;
    }
    
    public abstract double deposit(double amount);
    public abstract double withdrawal(double amount);
    
    @Override
    public String toString() {
        return "Account Number: " + accNumber + "\n" +
               "Owner: " + owner.getName() + "\n" +
               "Balance: $" + String.format("%.2f", balance);
    }
}