/*
 * Adult.java
 */
public class Adult extends Customer {
    private final double savingsInterest = 0.03; 
    private final double checkInterest = 0.01;   
    private final double checkCharge = 1.0;      
    private final double overdraftPenalty = 30.0;
    
  public Adult(String name, String address, int age, String phoneNumber, String customerNumber) {
        super(name, address, age, phoneNumber, customerNumber, 1);
    }
  
    public String getType() {
        return "Adult";
    }
    public double getSavingsInterest() {
        return savingsInterest;
    }
    public double getCheckInterest() {
        return checkInterest;
    }
    public double getCheckCharge() {
        return checkCharge;
    }
    public double getOverdraftPenalty() {
        return overdraftPenalty;
    }
}